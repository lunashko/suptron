"use client";

import Image from "next/image";

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-indigo-950">
      <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500"></div>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-300 dark:bg-purple-900 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-yellow-300 dark:bg-yellow-900 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-20 w-80 h-80 bg-pink-300 dark:bg-pink-900 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-2 hidden md:block">
            <div className="h-full border-r border-gray-200 dark:border-gray-700"></div>
          </div>
          
          <main className="text-center md:col-span-8 py-12">
            <div className="flex flex-col items-center gap-8 backdrop-blur-sm bg-white/30 dark:bg-gray-900/30 p-8 rounded-2xl shadow-lg border border-white/50 dark:border-gray-800/50">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
                <Image
                  className="dark:invert relative rounded-full p-2"
                  src="/nextjs.png"
                  alt="Next.js logo"
                  width={180}
                  height={37}
                  priority
                />
              </div>
              
              <h1 className="text-5xl font-extrabold">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
                  Next.js + Suptron
                </span>
              </h1>
              
              <p className="text-xl text-gray-700 dark:text-gray-300 max-w-lg leading-relaxed">
                Modern platform for creating fast, beautiful, and scalable web applications with superior user experience
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mt-4">
                <button className="px-8 py-3 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium hover:shadow-lg hover:scale-105 transform transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-50">
                  Get Started
                </button>
                <button className="px-8 py-3 rounded-full bg-white dark:bg-gray-800 text-gray-800 dark:text-white border border-gray-200 dark:border-gray-700 font-medium hover:shadow-lg hover:scale-105 transform transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-50">
                  Documentation
                </button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full mt-12">
                {[
                  {
                    title: "Rapid Development",
                    description: "Create modern applications with minimal time investment",
                    icon: "⚡"
                  },
                  {
                    title: "Responsive Design",
                    description: "Adaptive interfaces for any device and screen resolution",
                    icon: "📱"
                  },
                  {
                    title: "High Performance",
                    description: "Optimized code for maximum loading speed",
                    icon: "🚀"
                  }
                ].map((feature, index) => (
                  <div key={index} className="flex flex-col items-center p-6 bg-white/50 dark:bg-gray-800/50 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-gray-700">
                    <div className="text-4xl mb-4">{feature.icon}</div>
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">{feature.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 text-sm">{feature.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </main>
          
          <div className="md:col-span-2 hidden md:block">
            <div className="h-full border-l border-gray-200 dark:border-gray-700"></div>
          </div>
        </div>
      </div>
      
      <footer className="w-full text-center p-4 text-gray-500 dark:text-gray-400 mt-auto text-sm">
        <p>© 2023 Suptron. All rights reserved.</p>
      </footer>
      
      <BlobAnimation />
    </div>
  );
}

function BlobAnimation() {
  return (
    <style jsx global>{`
      @keyframes blob {
        0% {
          transform: translate(0px, 0px) scale(1);
        }
        33% {
          transform: translate(30px, -50px) scale(1.1);
        }
        66% {
          transform: translate(-20px, 20px) scale(0.9);
        }
        100% {
          transform: translate(0px, 0px) scale(1);
        }
      }
      .animate-blob {
        animation: blob 7s infinite;
      }
      .animation-delay-2000 {
        animation-delay: 2s;
      }
      .animation-delay-4000 {
        animation-delay: 4s;
      }
    `}</style>
  );
}
