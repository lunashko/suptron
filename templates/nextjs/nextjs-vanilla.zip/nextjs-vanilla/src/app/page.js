"use client";

import styles from "./page.module.css";

export default function Home() {
  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <main className={styles.main}>
          <h1>
            <span>
              Next.js + Suptron
            </span>
          </h1>
          
          <p className={styles.centerText}>
            Welcome to your modern Next.js application!
          </p>
          
          <p className={styles.centerText}>
            Start development right now and create something amazing.
          </p>
        </main>
        
        <footer className={styles.footer}>
          &copy; {new Date().getFullYear()} - Created using Next.js
        </footer>
      </div>
    </div>
  );
}
